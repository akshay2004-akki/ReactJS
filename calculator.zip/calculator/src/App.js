/* eslint-disable no-eval */
//import logo from './logo.svg';
import './App.css';
import React, {useState} from 'react'

function App() {
  const [input, setInput] = useState('');
  const [res, setRes] = useState('');

  const handle = (val)=>{
    if(val==='='){
      try{
        setRes(eval(input).toString());
      }
      catch(error){
        setRes('Error');
        console.error("Error:", error);
      }
    }
    else if(val==='AC'){
      setInput('');
      setRes('');
    }
    else if(val==='b'){
      setInput(input.slice(0,-1));
    }
    else{
      setInput((prevVal)=> prevVal+val);
    }
  }
  return (
    <>
    <div className="container">
      <div className="result">
        <span className='text'>{input}</span>
        <div className='res'>{res}</div>
      </div>
      <br/>
      <div className="button">
        <button className="all-clear" onClick={()=>handle('AC')}>AC</button>
        <button className="item sign sign1" onClick={()=>handle('b')}>bkspc</button>
        <button className="item sign sign2" onClick={()=>handle('%')}>%</button>
        <button className="item sign sign3" onClick={()=>handle('/')}>/</button>
        <button className="icon item7" onClick={()=>handle('7')}>7</button>
        <button className="icon item8" onClick={()=>handle('8')}>8</button>
        <button className="icon item9" onClick={()=>handle('9')}>9</button>
        <button className="item sign sign4" onClick={()=>handle('*')}>&times;</button>
        <button className="icon item4" onClick={()=>handle('4')}>4</button>
        <button className="icon item5" onClick={()=>handle('5')}>5</button>
        <button className="icon item6" onClick={()=>handle('6')}>6</button>
        <button className="item sign sign5" onClick={()=>handle('-')}>-</button>
        <button className="icon item1" onClick={()=>handle('1')}>1</button>
        <button className="icon item2" onClick={()=>handle('2')}>2</button>
        <button className="icon item3" onClick={()=>handle('3')}>3</button>
        <button className="item sign sign6" onClick={()=>handle('+')}>+</button>
        <button className="icon item0" onClick={()=>handle('0')}>0</button>
        <button className="item sign sign7" onClick={()=>handle('=')}>=</button>
      </div>
    </div>
    </>
  );
}

export default App;
