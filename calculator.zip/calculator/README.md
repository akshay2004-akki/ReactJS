# calculator
 performs All the mathematical Calculations
